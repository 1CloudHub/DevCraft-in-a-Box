mupdf_location='https://mupdf.com/downloads/archive/mupdf-1.25.6-source.tar.gz'
